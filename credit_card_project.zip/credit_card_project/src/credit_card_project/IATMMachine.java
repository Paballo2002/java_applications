/**
 * 
 */
package credit_card_project;

/**
 * 
 */
public interface IATMMachine 
{
    public void withdrawing(double amount);
    public void deposit(double amount);
    public void checkBalance();
}
